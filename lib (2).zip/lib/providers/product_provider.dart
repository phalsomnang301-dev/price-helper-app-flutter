import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:getdatabacken/lib/models/product_model.dart';
import '../services/product_service.dart';

final _productServiceProvider = Provider<ProductService>((ref) {
  return ProductService();
});

class _ProductProvider extends AsyncNotifier<List<ProductModel>> {
  @override
  FutureOr<List<ProductModel>> build() {
    final service = ref.watch(_productServiceProvider);
    return service.fetch();
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      final service = ref.read(_productServiceProvider);
      return service.fetch();
    });
  }

  //   Future<void> createStudent(Product item) async {
  //     final service = ref.read(_studentServiceProvider);
  //     await service.create(item);
  //     ref.invalidateSelf();
  //     await future;
  //   }

  //   Future<void> updateStudent(StudentModel item) async {
  //     final service = ref.read(_studentServiceProvider);
  //     await service.update(item);
  //     ref.invalidateSelf();
  //     await future;
  //   }

  //   Future<void> deleteStudent(int id) async {
  //     final service = ref.read(_studentServiceProvider);
  //     await service.delete(id);
  //     ref.invalidateSelf();
  //     await future;
  //   }

  // }
}

final productNotifierProvider = AsyncNotifierProvider(_ProductProvider.new);
