import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:getdatabacken/lib/models/product_model.dart';
import 'package:getdatabacken/lib/services/base.dart';
import 'package:http/http.dart' as http;

class ProductService {
  final _baseUrl = BaseURL.base;

  Future<List<ProductModel>> fetch() async {
    final url = "$_baseUrl/api/products";

    try {
      final response = await http
          .get(Uri.parse(url))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        // ប្រើ utf8.decode ការពារដាច់អក្សរខ្មែរ
        final responseBody = utf8.decode(response.bodyBytes);
        final list = await compute(productModelFromJson, responseBody);
        return list;
      }
      throw Exception('Server Error: ${response.statusCode}');
    } catch (e) {
      throw Exception('Failed to load products: $e');
    }
  }

  // Future<bool> create(Product item) async {
  //   final url = "$_baseUrl/api/products";

  //   try {
  //     final response = await http
  //         .post(
  //           Uri.parse(url),
  //           headers: {
  //             'Content-Type': 'application/json',
  //             "Accept": "application/json",
  //           },
  //           body: jsonEncode(item.toJson()),
  //         )
  //         .timeout(const Duration(seconds: 10));
  //     if (response.statusCode == 201) {
  //       debugPrint("response body: ${response.body}");
  //       return true;
  //     }
  //     throw Exception('Server Error: ${response.statusCode}');
  //   } catch (e) {
  //     throw Exception('Failed to posting students: $e');
  //   }
  // }

  // Future<bool> update(StudentModel item) async {
  //   final url = "$_baseUrl/api/students/${item.id}";

  //   final body = {"full_name": item.fullName};

  //   try {
  //     final response = await http
  //         .put(
  //           Uri.parse(url),
  //           headers: {'Content-Type': 'application/json'},
  //           body: jsonEncode(body),
  //         )
  //         .timeout(const Duration(seconds: 10));
  //     if (response.statusCode == 200) {
  //       debugPrint("response body: ${response.body}");
  //       return true;
  //     }
  //     throw Exception('Server Error: ${response.statusCode}');
  //   } catch (e) {
  //     throw Exception('Failed to updating students: $e');
  //   }
  // }

  // Future<bool> delete(int id) async {
  //   final url = "$_baseUrl/api/students/$id";

  //   try {
  //     final response = await http
  //         .delete(Uri.parse(url))
  //         .timeout(const Duration(seconds: 10));
  //     if (response.statusCode == 200) {
  //       debugPrint("response body: ${response.body}");
  //       return true;
  //     }
  //     throw Exception('Server Error: ${response.statusCode}');
  //   } catch (e) {
  //     throw Exception('Failed to deleting students: $e');
  //   }
  // }
}
