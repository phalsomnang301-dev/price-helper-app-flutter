import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/meal_detail_model.dart';
import '../models/meal_model.dart';
import '../services/meal_service.dart';

final _mealServiceProvider = Provider<MealService>((ref) {
  return MealService();
});

class MealProvider extends AsyncNotifier<List<Meal>> {
  @override
  FutureOr<List<Meal>> build() {
    final service = ref.watch(_mealServiceProvider);
    return service.fetchMeals();
  }

  Future<void> refreshMeals() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      final service = ref.read(_mealServiceProvider);
      return service.fetchMeals();
    });
  }
}

final mealNotifierProvider = AsyncNotifierProvider(MealProvider.new);

// final mealDetailProvider = FutureProvider.autoDispose.family<MealElement, String>((
final mealDetailProvider = FutureProvider.family<MealElement, String>((
  ref,
  id,
) {
  final service = ref.watch(_mealServiceProvider);
  return service.get(id);
});
