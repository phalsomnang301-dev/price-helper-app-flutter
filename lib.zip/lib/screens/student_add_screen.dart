import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/material.dart';

import '../models/student_model.dart';
import '../providers/student_provider.dart';
import '../utils/message.dart';

class StudentAddScreen extends ConsumerStatefulWidget {
  const StudentAddScreen({super.key});

  @override
  ConsumerState<StudentAddScreen> createState() => _StudentAddScreenState();
}

class _StudentAddScreenState extends ConsumerState<StudentAddScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add New Student")),
      body: _buildBodyWithLoading(),
    );
  }

  bool _loading = false; //set to true for debugging

  Widget _buildBodyWithLoading() {
    return Stack(children: [_buildBody(), if (_loading) _buildLoadingCover()]);
  }

  Widget _buildLoadingCover() {
    return Container(
      color: Colors.black38,
      alignment: .center,
      child: CircularProgressIndicator(),
    );
  }

  final _formKey = GlobalKey<FormState>();

  Widget _buildBody() {
    return Form(
      key: _formKey,
      child: ListView(
        padding: .all(8),
        children: [_buildFullNameTextField(), _buildSaveButton()],
      ),
    );
  }

  final _fullNameCtrl = TextEditingController();

  Widget _buildFullNameTextField() {
    return TextFormField(
      controller: _fullNameCtrl,
      decoration: InputDecoration(
        border: OutlineInputBorder(),
        prefixIcon: Icon(Icons.person),
        hintText: "Full Name",
      ),
      validator: (text) {
        if (text!.isEmpty) {
          return "Full Name is required";
        }
        return null; // no error, return null
      },
    );
  }

  Widget _buildSaveButton() {
    return FilledButton.icon(
      onPressed: () async {
        if (_formKey.currentState!.validate()) {
          final item = StudentModel(id: 0, fullName: _fullNameCtrl.text.trim());

          try {
            setState(() {
              _loading = true;
            });
            await ref
                .read(studentNotifierProvider.notifier)
                .createStudent(item);
            showMessage(context, "Student createed successfully");
          } catch (e) {
            debugPrint("Error while updating: ${e.toString()}");
            showMessage(context, "Error while creating: ${e.toString()}");
          } finally {
            setState(() {
              _loading = false;
            });
          }

        }
      },
      icon: Icon(Icons.save_alt),
      label: Text("SAVE"),
    );
  }
}
