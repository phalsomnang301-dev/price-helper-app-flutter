import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:skeletonizer/skeletonizer.dart';

import '../models/student_model.dart';
import '../providers/student_provider.dart';
import '../utils/message.dart';

class StudentScreen extends ConsumerStatefulWidget {
  const StudentScreen({super.key});

  @override
  ConsumerState<StudentScreen> createState() => _MealScreenState();
}

class _MealScreenState extends ConsumerState<StudentScreen> {
  bool _showButton = false;

  @override
  void initState() {
    super.initState();
    _scroller.addListener(() {
      if (_scroller.position.pixels < 500) {
        setState(() {
          _showButton = false;
        });
      } else {
        setState(() {
          _showButton = true;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: _buildBody(),
      floatingActionButton: _showButton ? _buildFloating() : null,
    );
  }

  AppBar _buildAppBar() => AppBar(
    title: Text("Student Screen"),
    actions: [
      IconButton(
        onPressed: () {
          Navigator.of(context).pushNamed("/add");
        },
        icon: Icon(Icons.person_add),
      ),
    ],
  );

  Widget _buildBody() {
    final studentAsync = ref.watch(studentNotifierProvider);

    return Center(
      child: RefreshIndicator(
        onRefresh: () async {
          ref.watch(studentNotifierProvider.notifier).refresh();
        },
        child: studentAsync.when(
          data: (items) {
            return _buildGridView(items);
          },
          error: (e, s) {
            debugPrint("Error: ${e.toString()}");
            debugPrint("TrackTrace: ${s.toString()}");
            return Text("Error: ${e.toString()}");
          },
          loading: () {
            return _buildSkeleton();
          },
        ),
      ),
    );
  }

  Widget _buildFloating() {
    return FloatingActionButton(
      shape: CircleBorder(),
      onPressed: () {
        _scroller.animateTo(
          0,
          duration: Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      },
      child: Icon(Icons.arrow_upward),
    );
  }

  Widget _buildSkeleton() {
    return Skeletonizer(
      child: GridView.builder(
        itemCount: 40,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 2 / 3,
        ),
        itemBuilder: (context, index) {
          return Card(
            child: Column(
              mainAxisAlignment: .center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "asdsadasd sadassa",
                    maxLines: 1,
                    overflow: .ellipsis,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  final _scroller = ScrollController();

  Widget _buildGridView(List<StudentModel> items) {
    if (items.isEmpty) {
      return Text("No Students");
    }

    return GridView.builder(
      controller: _scroller,
      physics: BouncingScrollPhysics(),
      itemCount: items.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 2 / 1,
      ),
      itemBuilder: (context, index) {
        final item = items[index];
        return _buildItem(item);
      },
    );
  }

  Widget _buildItem(StudentModel item) {
    return InkWell(
      onTap: () {
        Navigator.of(context).pushNamed('/edit', arguments: item);
      },
      child: Card(
        child: Column(
          mainAxisAlignment: .center,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(item.fullName, maxLines: 1, overflow: .ellipsis),
            ),
            Row(
              mainAxisAlignment: .end,
              children: [_builDeleteIconButton(item)],
            ),
          ],
        ),
      ),
    );
  }

  IconButton _builDeleteIconButton(StudentModel item) {
    return IconButton(
      onPressed: () async {
        bool deleted = await showDeleteDialog(context) ?? false;
        if (deleted) {
          ref
              .read(studentNotifierProvider.notifier)
              .deleteStudent(item.id)
              .then((value) {
                showMessage(context, "Student deleted successfully");
              })
              .onError((e, s) {
                debugPrint("deleting error: ${e.toString()}");
                showMessage(context, "Student deleted failed");
              });
        }
      },
      icon: Icon(Icons.delete),
    );
  }
}
