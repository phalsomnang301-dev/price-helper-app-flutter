import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/material.dart';
import '../providers/student_provider.dart';
import '../models/student_model.dart';
import '../utils/message.dart';

class StudentEditScreen extends ConsumerStatefulWidget {
  const StudentEditScreen({super.key});

  @override
  ConsumerState<StudentEditScreen> createState() => _StudentEditScreenState();
}

class _StudentEditScreenState extends ConsumerState<StudentEditScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsFlutterBinding.ensureInitialized();
  }

  late StudentModel _student;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final item = ModalRoute.of(context)?.settings.arguments as StudentModel?;

    if (item != null) {
      _student = item;
      _fullNameCtrl.text = item.fullName;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Edit Student")),
      body: _buildBodyWithLoading(),
    );
  }

  bool _loading = false; //set to true for debugging

  Widget _buildBodyWithLoading() {
    return Stack(children: [_buildBody(), if (_loading) _buildLoadingCover()]);
  }

  Widget _buildLoadingCover() {
    return Container(
      color: Colors.black38,
      alignment: .center,
      child: CircularProgressIndicator(),
    );
  }

  final _formKey = GlobalKey<FormState>();

  Widget _buildBody() {
    return Form(
      key: _formKey,
      child: ListView(
        padding: .all(8),
        children: [_buildFullNameTextField(), _buildSaveButton()],
      ),
    );
  }

  final _fullNameCtrl = TextEditingController();

  Widget _buildFullNameTextField() {
    return TextFormField(
      controller: _fullNameCtrl,
      decoration: InputDecoration(
        border: OutlineInputBorder(),
        prefixIcon: Icon(Icons.person),
        hintText: "Full Name",
      ),
      validator: (text) {
        if (text!.isEmpty) {
          return "Full Name is required";
        }
        return null; // no error, return null
      },
    );
  }

  Widget _buildSaveButton() {
    return FilledButton.icon(
      onPressed: () async {
        if (_formKey.currentState!.validate()) {
          final item = StudentModel(
            id: _student.id,
            fullName: _fullNameCtrl.text.trim(),
          );

          try {
            setState(() {
              _loading = true;
            });
            await ref
                .read(studentNotifierProvider.notifier)
                .updateStudent(item);
            showMessage(context, "Student updated successfully");
          } catch (e) {
            debugPrint("Error while updating: ${e.toString()}");
            showMessage(context, "Error while updating: ${e.toString()}");
          } finally {
            setState(() {
              _loading = false;
            });
          }
        }
      },
      icon: Icon(Icons.save_alt),
      label: Text("SAVE"),
    );
  }
}
